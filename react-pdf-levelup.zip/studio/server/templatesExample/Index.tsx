import { Layout, Div } from "@react-pdf-levelup/core"
import Header from "./components/Header"
import Main from "./components/Main"
import getFuentes from "./getFuentes"

const Index = ({ data }: any) => {

  const fullData = {
    nameDoc: data?.nameDoc || "OPEN SOURCE · REACT PDF LEVELUP",
  }

  getFuentes()

  const COLORS = {
    pageBg: "#f5f6fa",
  }

  const page = {
    backgroundColor: COLORS.pageBg,
    padding: 36,
    fontFamily: "Nunito",
  }

  return (
    <Layout style={page} pagination={false}>
      <Div>
        <Header data={fullData} />
        <Main />
      </Div>
    </Layout>
  )
}

export default Index

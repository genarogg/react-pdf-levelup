import React, { useEffect, useState } from "react"
import type { HighlighterCore } from "shiki/core"

// API "fine-grained" de Shiki: motor JS puro (sin WASM) + solo los lenguajes
// y el tema que este viewer necesita, en vez de shiki/bundle-web (que trae
// decenas de lenguajes precompilados e infla el build en varios MB).
//
// El highlighter es costoso de construir, así que se instancia UNA sola vez
// para toda la app y se reutiliza entre todos los <CodeBlock>.
let highlighterPromise: Promise<HighlighterCore> | null = null

function getHighlighter(): Promise<HighlighterCore> {
  if (!highlighterPromise) {
    highlighterPromise = Promise.all([
      import("shiki/core"),
      import("shiki/engine/javascript"),
      import("shiki/themes/github-dark.mjs"),
      import("shiki/langs/tsx.mjs"),
      import("shiki/langs/jsx.mjs"),
      import("shiki/langs/typescript.mjs"),
      import("shiki/langs/javascript.mjs"),
      import("shiki/langs/json.mjs"),
      import("shiki/langs/bash.mjs"),
    ]).then(
      ([
        { createHighlighterCore },
        { createJavaScriptRegexEngine },
        githubDark,
        tsx,
        jsx,
        typescript,
        javascript,
        json,
        bash,
      ]) =>
        createHighlighterCore({
          themes: [githubDark],
          langs: [tsx, jsx, typescript, javascript, json, bash],
          engine: createJavaScriptRegexEngine(),
        })
    )
  }
  return highlighterPromise
}

interface CodeBlockProps {
  /** Código fuente, tal cual viene dentro del fence de markdown */
  code: string
  /** Lenguaje declarado en el fence (```tsx, ```jsx, etc). Cae a "tsx" si no se reconoce. */
  language?: string
  /** Título opcional mostrado en la barra superior del bloque (ej: nombre de archivo) */
  filename?: string
}

const SUPPORTED_LANGS = new Set(["tsx", "jsx", "typescript", "javascript", "json", "bash", "ts", "js"])

function normalizeLang(lang?: string): string {
  const clean = (lang || "").toLowerCase().trim()
  if (clean === "ts") return "typescript"
  if (clean === "js") return "javascript"
  if (SUPPORTED_LANGS.has(clean)) return clean
  return "tsx"
}

const CodeBlock: React.FC<CodeBlockProps> = ({ code, language, filename }) => {
  const [html, setHtml] = useState<string | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [copied, setCopied] = useState(false)

  useEffect(() => {
    let cancelled = false
    const lang = normalizeLang(language)

    getHighlighter()
      .then((highlighter) => {
        if (cancelled) return
        const out = highlighter.codeToHtml(code.replace(/\n$/, ""), {
          lang,
          theme: "github-dark",
        })
        setHtml(out)
      })
      .catch((err) => {
        if (cancelled) return
        console.error("[CodeBlock] No se pudo cargar el highlighter de Shiki:", err)
        setError(err instanceof Error ? err.message : String(err))
      })

    return () => {
      cancelled = true
    }
  }, [code, language])

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(code)
      setCopied(true)
      setTimeout(() => setCopied(false), 1500)
    } catch {
      // Sin permisos de portapapeles: no rompemos la UI por esto.
    }
  }

  const handleOpenInPlayground = () => {
    try {
      localStorage.setItem("playground:demo:code", code)
      localStorage.setItem("playground:demo:ts", Date.now().toString())
      const base = import.meta.env.BASE_URL || "/"
      const prefix = base.endsWith("/") ? base.slice(0, -1) : base
      const url = `${prefix}/playground/demo`
      window.open(url, "_blank", "noopener,noreferrer")
    } catch (err) {
      console.error("[CodeBlock] Error al abrir en playground:", err)
    }
  }

  return (
    <div className="relative rounded-lg border border-white/10 bg-[#0d1117] overflow-hidden my-4">
      <div className="flex items-center justify-between px-4 py-2 border-b border-white/10 bg-white/[0.03]">
        <span className="text-xs font-mono text-gray-400">
          {filename || normalizeLang(language)}
        </span>
        <div className="flex items-center gap-2">
          {["tsx", "jsx", "typescript", "javascript", "ts", "js"].includes(
            normalizeLang(language)
          ) && (
            <button
              onClick={handleOpenInPlayground}
              className="text-xs text-gray-400 hover:text-white transition-colors px-2 py-1 rounded-md hover:bg-white/10 flex items-center gap-1"
              title="Abrir este código en el Playground"
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="w-3.5 h-3.5"
              >
                <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6" />
                <polyline points="15 3 21 3 21 9" />
                <line x1="10" y1="14" x2="21" y2="3" />
              </svg>
              Abrir en Playground
            </button>
          )}
          <button
            onClick={handleCopy}
            className="text-xs text-gray-400 hover:text-white transition-colors px-2 py-1 rounded-md hover:bg-white/10"
          >
            {copied ? "¡Copiado!" : "Copiar"}
          </button>
        </div>
      </div>

      {html ? (
        <div
          className="text-sm leading-relaxed overflow-x-auto [&>pre]:p-4 [&>pre]:!bg-transparent [&>pre]:m-0"
          dangerouslySetInnerHTML={{ __html: html }}
        />
      ) : (
        <pre className="p-4 text-sm text-gray-300 overflow-x-auto m-0">
          <code>{code}</code>
        </pre>
      )}
      {error && (
        <div className="px-4 py-2 text-xs text-red-300 bg-red-950/40 border-t border-red-500/20">
          Resaltado de sintaxis no disponible ({error}). Revisá la versión de{" "}
          <code className="px-1 py-0.5 rounded bg-white/10">shiki</code> instalada.
        </div>
      )}
    </div>
  )
}

export default CodeBlock
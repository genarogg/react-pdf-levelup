import LayoutPDF from "./core/LayoutPDF"
import { Table, Thead, Tbody, Tr, Th, Td } from "./core/Tablet"
import { Strong } from "./core/Etiquetas"

export { LayoutPDF, Table, Thead, Tbody, Tr, Th, Td, Strong }


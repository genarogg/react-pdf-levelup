import React from "react"
import { View, StyleSheet } from "@react-pdf/renderer"

type ViewBaseProps = React.ComponentProps<typeof View>

interface ContainerProps extends Omit<ViewBaseProps, "style"> {
  children?: React.ReactNode
  style?: any
}

interface RowProps extends Omit<ViewBaseProps, "style"> {
  children?: React.ReactNode
  style?: any
}

interface ColProps extends Omit<ViewBaseProps, "style"> {
  children?: React.ReactNode
  style?: any
}

const styles = StyleSheet.create({
  container: {
    width: "100%",
  },
  row: {
    flexDirection: "row",
    flexWrap: "wrap",
  },
  col1: { width: "8.33%" },
  col2: { width: "16.66%" },
  col3: { width: "25%" },
  col4: { width: "33.33%" },
  col5: { width: "41.66%" },
  col6: { width: "50%" },
  col7: { width: "58.33%" },
  col8: { width: "66.66%" },
  col9: { width: "75%" },
  col10: { width: "83.33%" },
  col11: { width: "91.66%" },
  col12: { width: "100%" },
})

export const Container: React.FC<ContainerProps> = ({ children, style, ...rest }) => (
  <View style={[styles.container, style]} {...rest}>{children}</View>
)

export const Row: React.FC<RowProps> = ({ children, style, ...rest }) => (
  <View style={[styles.row, style]} {...rest}>{children}</View>
)

export const Col1: React.FC<ColProps> = ({ children, style, ...rest }) => (
  <View style={[styles.col1, style]} {...rest}>{children}</View>
)

export const Col2: React.FC<ColProps> = ({ children, style, ...rest }) => (
  <View style={[styles.col2, style]} {...rest}>{children}</View>
)

export const Col3: React.FC<ColProps> = ({ children, style, ...rest }) => (
  <View style={[styles.col3, style]} {...rest}>{children}</View>
)

export const Col4: React.FC<ColProps> = ({ children, style, ...rest }) => (
  <View style={[styles.col4, style]} {...rest}>{children}</View>
)

export const Col5: React.FC<ColProps> = ({ children, style, ...rest }) => (
  <View style={[styles.col5, style]} {...rest}>{children}</View>
)

export const Col6: React.FC<ColProps> = ({ children, style, ...rest }) => (
  <View style={[styles.col6, style]} {...rest}>{children}</View>
)

export const Col7: React.FC<ColProps> = ({ children, style, ...rest }) => (
  <View style={[styles.col7, style]} {...rest}>{children}</View>
)

export const Col8: React.FC<ColProps> = ({ children, style, ...rest }) => (
  <View style={[styles.col8, style]} {...rest}>{children}</View>
)

export const Col9: React.FC<ColProps> = ({ children, style, ...rest }) => (
  <View style={[styles.col9, style]} {...rest}>{children}</View>
)

export const Col10: React.FC<ColProps> = ({ children, style, ...rest }) => (
  <View style={[styles.col10, style]} {...rest}>{children}</View>
)

export const Col11: React.FC<ColProps> = ({ children, style, ...rest }) => (
  <View style={[styles.col11, style]} {...rest}>{children}</View>
)

export const Col12: React.FC<ColProps> = ({ children, style, ...rest }) => (
  <View style={[styles.col12, style]} {...rest}>{children}</View>
)